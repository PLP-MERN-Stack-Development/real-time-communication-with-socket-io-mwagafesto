import { v4 as uuid } from 'uuid'

// In-memory store (demo only)
export const users = []  // {id, username, password}
export const rooms = [
  { id: 'general', name: 'General' },
  { id: 'random', name: 'Random' },
  { id: 'help', name: 'Help' }
]
export const messages = {
  general: [], random: [], help: []
}
export const privateMessages = {
  // key: [ { id, from, to, body, ts, readBy: [userId] } ]
}

export const online = new Map() // userId -> Set(socketId)

export function createStore() {
  return {
    users,
    rooms,
    messages,
    privateMessages,
    online,
    createMessage({ roomId, from, body }) {
      const m = { id: uuid(), roomId, from, body, ts: Date.now(), readBy: [from] }
      if (!this.messages[roomId]) this.messages[roomId] = []
      this.messages[roomId].push(m)
      return m
    },
    createPrivateMessage({ from, to, body }) {
      const key = [from, to].sort().join('|')
      const m = { id: uuid(), from, to, body, ts: Date.now(), readBy: [from] }
      if (!this.privateMessages[key]) this.privateMessages[key] = []
      this.privateMessages[key].push(m)
      return { key, m }
    },
    markReadRoom({ roomId, userId, messageIds }) {
      const list = this.messages[roomId] || []
      for (const msg of list) {
        if (!messageIds || messageIds.includes(msg.id)) {
          if (!msg.readBy.includes(userId)) msg.readBy.push(userId)
        }
      }
      return list
    },
    markReadPrivate({ from, to, userId, messageIds }) {
      const key = [from, to].sort().join('|')
      const list = this.privateMessages[key] || []
      for (const msg of list) {
        if (!messageIds || messageIds.includes(msg.id)) {
          if (!msg.readBy.includes(userId)) msg.readBy.push(userId)
        }
      }
      return list
    }
  }
}
