import express from 'express'
import { signJwt } from './jwt.js'
import { users } from '../models/store.js'

const router = express.Router()

// Simple username/password (plaintext for demo only).
// In production, hash passwords!
router.post('/register', (req, res) => {
  const { username, password } = req.body || {}
  if (!username || !password) return res.status(400).json({ error: 'username and password required' })
  const exists = users.find(u => u.username === username)
  if (exists) return res.status(400).json({ error: 'username already exists' })
  const id = String(Date.now())
  users.push({ id, username, password })
  const token = signJwt({ id, username })
  res.json({ token, user: { id, username } })
})

router.post('/login', (req, res) => {
  const { username, password } = req.body || {}
  const user = users.find(u => u.username === username && u.password == password)
  if (!user) return res.status(401).json({ error: 'invalid credentials' })
  const token = signJwt({ id: user.id, username: user.username })
  res.json({ token, user: { id: user.id, username: user.username } })
})

export default router
