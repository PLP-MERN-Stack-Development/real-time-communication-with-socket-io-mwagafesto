import jwt from 'jsonwebtoken'
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me'
export const TOKEN_EXPIRY = '7d'

export function signJwt(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRY })
}

export function verifySocketToken(socket, next) {
  try {
    const token = socket.handshake.auth?.token || socket.handshake.headers['x-auth-token']
    if (!token) return next(new Error('No token provided'))
    const decoded = jwt.verify(token, JWT_SECRET)
    socket.user = decoded // { id, username }
    next()
  } catch (e) {
    next(new Error('Invalid token'))
  }
}
