import 'dotenv/config'
import express from 'express'
import http from 'http'
import cors from 'cors'
import { Server as SocketIOServer } from 'socket.io'
import authRouter from './utils/auth.js'
import { verifySocketToken } from './utils/jwt.js'
import { createStore } from './models/store.js'
import { initSocketHandlers } from './socket/index.js'

const PORT = process.env.PORT || 4000
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:5173'

const app = express()
app.use(cors({ origin: CORS_ORIGIN, credentials: true }))
app.use(express.json())

// Simple health
app.get('/health', (_req, res) => res.json({ ok: true }))

// REST auth routes
app.use('/api/auth', authRouter)

// HTTP + Socket
const server = http.createServer(app)
const io = new SocketIOServer(server, {
  cors: { origin: CORS_ORIGIN, methods: ['GET','POST'] }
})

// In-memory store (users, rooms, messages, presence)
const store = createStore()

// Attach middleware for auth on socket connection
io.use(verifySocketToken)

io.on('connection', (socket) => {
  initSocketHandlers(io, socket, store)
})

server.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`))
