export function initSocketHandlers(io, socket, store) {
  const user = socket.user // { id, username }

  // --- Presence tracking ---
  if (!store.online.has(user.id)) {
    store.online.set(user.id, new Set())
  }
  store.online.get(user.id).add(socket.id)
  broadcastPresence()

  function broadcastPresence() {
    io.emit('presence:update', Array.from(store.online.keys()))
  }

  // Auto-join a default room
  socket.join('general')

  // Bootstrap client
  socket.emit('bootstrap', {
    me: user,
    rooms: store.rooms,
    onlineUsers: Array.from(store.online.keys()),
    recent: {
      general: (store.messages.general || []).slice(-50),
      random: (store.messages.random || []).slice(-50),
      help: (store.messages.help || []).slice(-50)
    }
  })

  // Join/leave rooms
  socket.on('room:join', (roomId) => socket.join(roomId))
  socket.on('room:leave', (roomId) => socket.leave(roomId))

  // --- Public room message ---
  socket.on('msg:room', ({ roomId, body }) => {
    if (!roomId || !body) return
    const msg = store.createMessage({ roomId, from: user.id, body })
    io.to(roomId).emit('msg:room', { roomId, msg })
  })

  // --- Private message ---
  socket.on('msg:pm', ({ to, body }) => {
    if (!to || !body) return
    const { key, m } = store.createPrivateMessage({ from: user.id, to, body })
    // Emit to both users involved
    io.to(getUserRoom(user.id)).emit('msg:pm', { key, msg: m })
    io.to(getUserRoom(to)).emit('msg:pm', { key, msg: m, notify: true })
  })

  // Typing indicators
  socket.on('typing:room', ({ roomId, isTyping }) => {
    socket.to(roomId).emit('typing:room', { roomId, userId: user.id, isTyping: !!isTyping })
  })
  socket.on('typing:pm', ({ to, isTyping }) => {
    socket.to(getUserRoom(to)).emit('typing:pm', { from: user.id, isTyping: !!isTyping })
  })

  // Read receipts
  socket.on('read:room', ({ roomId, messageIds }) => {
    const list = store.markReadRoom({ roomId, userId: user.id, messageIds })
    io.to(roomId).emit('read:room', { roomId, userId: user.id, messageIds })
  })
  socket.on('read:pm', ({ withUserId, messageIds }) => {
    store.markReadPrivate({ from: user.id, to: withUserId, userId: user.id, messageIds })
    store.markReadPrivate({ from: withUserId, to: user.id, userId: user.id, messageIds })
    io.to(getUserRoom(user.id)).emit('read:pm', { withUserId, readerId: user.id, messageIds })
    io.to(getUserRoom(withUserId)).emit('read:pm', { withUserId: user.id, readerId: user.id, messageIds })
  })

  // Create a per-user "room" (for PM delivery / notifications)
  function getUserRoom(uid) {
    return `user:${uid}`
  }
  socket.join(getUserRoom(user.id))

  // Cleanup on disconnect
  socket.on('disconnect', () => {
    const set = store.online.get(user.id)
    if (set) {
      set.delete(socket.id)
      if (set.size === 0) store.online.delete(user.id)
    }
    broadcastPresence()
  })
}
