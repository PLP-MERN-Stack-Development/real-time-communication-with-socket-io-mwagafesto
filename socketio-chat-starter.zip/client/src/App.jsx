import React, { useState, useEffect } from 'react'
import { AuthProvider, useAuth } from './context/AuthContext.jsx'
import { SocketProvider } from './context/SocketProvider.jsx'
import Login from './pages/Login.jsx'
import Chat from './pages/Chat.jsx'

function AppInner(){
  const { user } = useAuth()
  return user ? <Chat/> : <Login/>
}

export default function App(){
  return (
    <AuthProvider>
      <SocketProvider>
        <AppInner/>
      </SocketProvider>
    </AuthProvider>
  )
}
