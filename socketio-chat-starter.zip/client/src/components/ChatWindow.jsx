import React, { useEffect, useRef, useState } from 'react'
import { useSocket } from '../context/SocketProvider.jsx'
import MessageInput from './MessageInput.jsx'
import TypingIndicator from './TypingIndicator.jsx'

export default function ChatWindow({ activeRoom, pmWith }){
  const { socket, bootstrap, user } = useSocket()
  const [messages, setMessages] = useState([])
  const [typing, setTyping] = useState({}) // userId->bool
  const bottomRef = useRef(null)

  // Initial load
  useEffect(() => {
    if (!socket) return
    function onRoomMsg({ roomId, msg }){
      if (activeRoom === roomId && !pmWith) setMessages(prev => [...prev, msg])
    }
    function onPmMsg({ key, msg, notify }){
      if (pmWith && (msg.from === pmWith || msg.to === pmWith)) setMessages(prev => [...prev, msg])
      if (notify && document.hidden && Notification.permission === 'granted'){
        new Notification('New private message')
      }
    }
    function onTypingRoom({ roomId, userId, isTyping }){
      if (activeRoom === roomId && !pmWith) setTyping(prev => ({...prev, [userId]: isTyping}))
    }
    function onTypingPm({ from, isTyping }){
      if (pmWith === from) setTyping(prev => ({...prev, [from]: isTyping}))
    }
    function onBootstrap(data){
      if (!pmWith && activeRoom) setMessages(data.recent[activeRoom] || [])
    }

    socket.on('msg:room', onRoomMsg)
    socket.on('msg:pm', onPmMsg)
    socket.on('typing:room', onTypingRoom)
    socket.on('typing:pm', onTypingPm)
    socket.on('bootstrap', onBootstrap)

    return () => {
      socket.off('msg:room', onRoomMsg)
      socket.off('msg:pm', onPmMsg)
      socket.off('typing:room', onTypingRoom)
      socket.off('typing:pm', onTypingPm)
      socket.off('bootstrap', onBootstrap)
    }
  }, [socket, activeRoom, pmWith])

  // Load PM history (in-memory only available server-side; here we just clear on switch)
  useEffect(() => {
    setMessages([])
    setTyping({})
  }, [activeRoom, pmWith])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  function send(body){
    if (pmWith){
      socket.emit('msg:pm', { to: pmWith, body })
    } else {
      socket.emit('msg:room', { roomId: activeRoom, body })
    }
  }
  function setTypingState(isTyping){
    if (pmWith){
      socket.emit('typing:pm', { to: pmWith, isTyping })
    } else {
      socket.emit('typing:room', { roomId: activeRoom, isTyping })
    }
  }

  return (
    <div style={{display:'grid', gridTemplateRows:'1fr auto', height:'100%'}}>
      <div style={{padding:12, overflowY:'auto'}}>
        {messages.map(m => (
          <div key={m.id} style={{margin:'4px 0'}}>
            <strong>{m.from===user.id?'Me':m.from}:</strong> {m.body}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div style={{borderTop:'1px solid #ddd', padding:12}}>
        <TypingIndicator typing={typing} currentUser={user.id} />
        <MessageInput onSend={send} onTyping={setTypingState} />
      </div>
    </div>
  )
}
