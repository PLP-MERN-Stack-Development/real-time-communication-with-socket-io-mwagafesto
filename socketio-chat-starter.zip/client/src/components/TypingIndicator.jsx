import React from 'react'

export default function TypingIndicator({ typing, currentUser }){
  const others = Object.entries(typing).filter(([uid, val]) => uid !== currentUser && val).map(([uid]) => uid)
  if (!others.length) return null
  return <div style={{fontSize:12, color:'#666'}}>{others.join(', ')} typing…</div>
}
