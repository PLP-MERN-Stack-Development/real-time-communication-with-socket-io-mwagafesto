import React from 'react'
export default function RoomList({ rooms, active, onSelect }){
  return (
    <ul>
      {rooms.map(r => (
        <li key={r.id}>
          <button disabled={active===r.id} onClick={()=>onSelect(r.id)}>{r.name}</button>
        </li>
      ))}
    </ul>
  )
}
