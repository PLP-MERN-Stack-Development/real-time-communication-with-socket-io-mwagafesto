import React, { useEffect, useRef, useState } from 'react'

export default function MessageInput({ onSend, onTyping }){
  const [value, setValue] = useState('')
  const typingRef = useRef(null)

  function send(){
    const body = value.trim()
    if (!body) return
    onSend(body)
    setValue('')
    onTyping(false)
  }

  // simple typing indicator debounce
  useEffect(() => {
    onTyping(true)
    clearTimeout(typingRef.current)
    typingRef.current = setTimeout(() => onTyping(false), 800)
    return () => clearTimeout(typingRef.current)
  }, [value])

  return (
    <div>
      <input
        style={{width:'80%'}}
        value={value}
        onChange={e=>setValue(e.target.value)}
        onKeyDown={e=>{ if(e.key==='Enter') send() }}
        placeholder="Type a message…"
      />
      <button style={{marginLeft:8}} onClick={send}>Send</button>
    </div>
  )
}
