import React, { useEffect, useMemo, useState } from 'react'
import { useSocket } from '../context/SocketProvider.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import RoomList from '../components/RoomList.jsx'
import ChatWindow from '../components/ChatWindow.jsx'

export default function Chat(){
  const { bootstrap, presence, socket, user } = useSocket()
  const { logout } = useAuth()
  const [activeRoom, setActiveRoom] = useState('general')
  const [pmWith, setPmWith] = useState(null) // userId for PM

  if(!bootstrap) return <div style={{padding:24}}>Connecting…</div>

  return (
    <div style={{display:'grid', gridTemplateColumns:'260px 1fr', height:'100vh', fontFamily:'system-ui'}}>
      <aside style={{borderRight:'1px solid #ddd', padding:12}}>
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
          <strong>{bootstrap.me.username}</strong>
          <button onClick={logout}>Logout</button>
        </div>
        <h3>Rooms</h3>
        <RoomList rooms={bootstrap.rooms} active={activeRoom} onSelect={(id)=>{ setPmWith(null); setActiveRoom(id); socket.emit('room:join', id) }} />
        <h3 style={{marginTop:16}}>Online</h3>
        <ul>
          {presence.filter(uid=>uid!==user.id).map(uid => (
            <li key={uid}><button onClick={()=>{ setPmWith(uid); }}>{uid}</button></li>
          ))}
        </ul>
      </aside>
      <main>
        <ChatWindow activeRoom={activeRoom} pmWith={pmWith} />
      </main>
    </div>
  )
}
