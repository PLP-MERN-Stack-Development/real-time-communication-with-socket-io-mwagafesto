import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext.jsx'

export default function Login(){
  const { login, register } = useAuth()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('login')
  const [error, setError] = useState('')

  async function submit(e){
    e.preventDefault()
    setError('')
    try{
      if(mode==='login') await login(username, password)
      else await register(username, password)
    }catch(err){ setError(String(err.message || err)) }
  }

  return (
    <div style={{maxWidth:420, margin:'60px auto', fontFamily:'system-ui'}}>
      <h1>Socket.io Chat</h1>
      <form onSubmit={submit}>
        <label>Username</label>
        <input value={username} onChange={e=>setUsername(e.target.value)} required />
        <label>Password</label>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        <button type="submit">{mode==='login'?'Login':'Register'}</button>
        <button type="button" onClick={()=>setMode(mode==='login'?'register':'login')} style={{marginLeft:8}}>
          Switch to {mode==='login'?'Register':'Login'}
        </button>
      </form>
      {error && <p style={{color:'crimson'}}>{error}</p>}
    </div>
  )
}
