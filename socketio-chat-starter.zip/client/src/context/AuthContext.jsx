import React, { createContext, useContext, useState } from 'react'

const AuthCtx = createContext(null)
export const useAuth = () => useContext(AuthCtx)

export function AuthProvider({ children }){
  const [token, setToken] = useState(localStorage.getItem('token') || '')
  const [user, setUser] = useState(token ? JSON.parse(localStorage.getItem('user') || 'null') : null)

  async function register(username, password){
    const res = await fetch('http://localhost:4000/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    })
    const data = await res.json()
    if (res.ok){
      setToken(data.token); localStorage.setItem('token', data.token)
      setUser(data.user); localStorage.setItem('user', JSON.stringify(data.user))
    } else {
      throw new Error(data.error || 'register failed')
    }
  }

  async function login(username, password){
    const res = await fetch('http://localhost:4000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    })
    const data = await res.json()
    if (res.ok){
      setToken(data.token); localStorage.setItem('token', data.token)
      setUser(data.user); localStorage.setItem('user', JSON.stringify(data.user))
    } else {
      throw new Error(data.error || 'login failed')
    }
  }

  function logout(){
    setToken(''); setUser(null)
    localStorage.removeItem('token'); localStorage.removeItem('user')
  }

  return <AuthCtx.Provider value={{ token, user, register, login, logout }}>{children}</AuthCtx.Provider>
}
