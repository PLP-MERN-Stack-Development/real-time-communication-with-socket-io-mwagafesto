import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { io } from 'socket.io-client'
import { useAuth } from './AuthContext.jsx'

const SocketCtx = createContext(null)
export const useSocket = () => useContext(SocketCtx)

export function SocketProvider({ children }){
  const { token, user } = useAuth()
  const [socket, setSocket] = useState(null)
  const [bootstrap, setBootstrap] = useState(null)
  const [presence, setPresence] = useState([])

  useEffect(() => {
    if (!token) { if (socket) socket.disconnect(); setSocket(null); return }
    const s = io('http://localhost:4000', { auth: { token } })
    setSocket(s)

    s.on('bootstrap', data => setBootstrap(data))
    s.on('presence:update', users => setPresence(users))

    return () => { s.disconnect() }
  }, [token])

  const value = useMemo(() => ({ socket, bootstrap, presence, user }), [socket, bootstrap, presence, user])
  return <SocketCtx.Provider value={value}>{children}</SocketCtx.Provider>
}
