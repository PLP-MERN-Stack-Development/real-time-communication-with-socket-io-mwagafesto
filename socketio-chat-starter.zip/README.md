# Socket.io Chat — Starter (Week 5)

This project is a working baseline for your Week 5 assignment. It includes:

- **Real-time messaging** via Socket.io
- **Auth** (JWT) with register/login endpoints
- **Presence** (online users)
- **Multiple rooms** and **private messaging**
- **Typing indicators**
- **Read receipts**
- **In-app notifications** for private messages
- React client with contexts for **Auth** and **Socket**

> Data is stored in-memory for simplicity (sufficient for assignment demos).
> You can swap the in-memory store with a DB later (Mongo/SQLite).

## Quick Start

### 1) Server
```bash
cd server
npm install
npm run dev
# Server on http://localhost:4000
```

### 2) Client
```bash
cd client
npm install
npm run dev
# App on http://localhost:5173
```

### Default Rooms
- general
- random
- help

### Env (optional)
Create `server/.env` to override defaults:
```
PORT=4000
JWT_SECRET=supersecret_change_me
CORS_ORIGIN=http://localhost:5173
```

## Features Implemented
- JWT auth (REST)
- Socket auth (token handshake)
- Join/leave rooms
- Public + private messages
- Typing indicators (`typing` event)
- Read receipts (`read` event)
- Presence (online users list)
- Notifications (UI badge + optional browser Notification permission)

## Scripts
- Server: `npm run dev` (nodemon)
- Client: `npm run dev` (Vite)

## Screenshots / GIFs
Add your screenshots or GIFs in this README under this section.

## Deployment
You can deploy server to Render/Railway/Heroku-alike and the client to Netlify/Vercel.
Set `CORS_ORIGIN` to your client URL and configure the Socket.io client URL accordingly.
