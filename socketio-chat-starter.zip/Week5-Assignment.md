# Week 5 — Real-Time Chat with Socket.io

- Complete the core chat, auth, presence.
- Add at least **3 advanced features** (this starter includes several).
- Update README with setup steps, features list, and screenshots/GIFs.
- (Optional) Deploy and add URLs.

> This starter is intentionally simple: in-memory storage, minimal styling.
> You can enhance persistence and UI as you like.
